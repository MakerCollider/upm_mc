#pragma once

#include <mraa.hpp>

namespace upm
{
    class Edison_serial
    {
    private:
    	mraa::Uart* dev;


    public:
        Edison_serial(unsigned char *devName);
        ~Edison_serial();

        int edison_serial_read(char * buffer);
	    int edison_serial_write(char * buffer, int len);
    };
}
