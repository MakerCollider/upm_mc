#include <math.h>
#include <unistd.h>
#include <iostream>
#include "edison_serial.h"

using namespace upm;
using namespace std;

Edison_serial::Edison_serial(char * devName)
{
    try {
        dev = new mraa::Uart(devName);
    } catch (std::exception& e) {
        std::cout << "Error while setting up raw UART, do you have a uart?" << std::endl;
        return 0;
    }
    if (dev->setBaudRate(115200) != mraa::MRAA_SUCCESS) {
        std::cout << "Error setting parity on UART" << std::endl;
        return 0;
    }
    if (dev->setMode(8, mraa::MRAA_UART_PARITY_NONE, 1) != mraa::MRAA_SUCCESS) {
        std::cout << "Error setting parity on UART" << std::endl;
        return 0;
    }
    if (dev->setFlowcontrol(false, false) != mraa::MRAA_SUCCESS) {
        std::cout << "Error setting flow control UART" << std::endl;
        return 0;
    }
    std::cout << "UART Init success!" << std::endl;
}

Edison_serial::~Edison_serial()
{
	delete dev;
	usleep(500);
}

int Edison_serial::edison_serial_read(char * buffer)
{
	int nread = 0;
	if(dev->dataAvailable(500))
    {//block and wait
        nread = dev->read(buffer,128);
    }
    if(nread>0)
    {
        std::cout << "Recv "<< nread << "bytes" << std::endl;
        std::cout << "Buffer: " << buffer << std::endl;
        return nread;
    }
    else
    {
        usleep(200000);
        return 0;
    }
}

int Edison_serial::edison_serial_write(char * buffer, int len)
{
	int nwrite = 0;
    nwrite = dev->write(buffer,len);
    if(-1 == nwrite)
    {
        std::cout << "Write Error! " << nwrite << std::endl;
        return -1;
    }
    else
    {
        return nwrite;
    }
}